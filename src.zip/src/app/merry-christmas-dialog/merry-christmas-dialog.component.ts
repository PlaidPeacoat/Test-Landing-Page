import { Component } from '@angular/core';

@Component({
  selector: 'app-merry-christmas-dialog',
  templateUrl: './merry-christmas-dialog.component.html',
  styleUrls: ['./merry-christmas-dialog.component.css']
})
export class MerryChristmasDialogComponent {

}
